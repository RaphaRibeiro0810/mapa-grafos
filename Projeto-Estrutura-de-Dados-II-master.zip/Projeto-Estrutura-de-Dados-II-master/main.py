# FILIPE DIAS CARVALHO DE AZEVEDO (22018849)
# MARIANE RAFAELA FERREIRA DOS SANTOS (21944418)
# OFLANDES RODRIGUES PADOVANI DA SILVA (14549778)
# RAPHAELA DE SOUZA RIBEIRO (22018101)

# O grapho será composto de nós e arestas, onde os nós representarão as cidades e as arestas as vias

# Dicionário que representa as cidades e suas conexões.
# Cada chave do dicionário é uma cidade(nó) e contém um vetor com todas as outras cidades que se ligam com ela
# All_Cities lista todas as cidades do grafo
nodes = {
        "All_Cities": ["Aspas", "Bambu", "Caju", "Doce", "Estrela", "Florida", "Galia", "Hebra", "Iaras", "Jaci", "Kiel"],
        "Aspas": ["Caju", "Bambu", "Estrela", "Florida"],
        "Bambu": ["Aspas", "Caju", "Florida", "Galia", "Jaci", "Kiel"],
        "Caju": ["Aspas", "Bambu", "Doce", "Estrela", "Galia", "Florida", "Hebra", "Iaras", "Jaci", "Kiel"],
        "Doce": ["Caju", "Estrela", "Florida", "Galia", "Hebra", "Iaras", "Jaci"],
        "Estrela": ["Aspas", "Caju", "Doce", "Florida", "Hebra", "Iaras"],
        "Florida": ["Aspas", "Bambu", "Caju", "Doce", "Estrela", "Galia", "Hebra", "Kiel"],
        "Galia": ["Bambu", "Caju", "Doce", "Florida", "Hebra", "Iaras", "Jaci", "Kiel"],
        "Hebra": ["Caju", "Doce", "Estrela", "Florida", "Galia", "Kiel"],
        "Iaras": ["Caju", "Doce", "Estrela", "Galia", "Jaci", "Kiel"],
        "Jaci": ["Bambu", "Caju", "Doce", "Galia", "Iaras"],
        "Kiel": ["Bambu", "Caju", "Florida", "Galia", "Hebra", "Iaras"]
    }

# As arestas são feitas por uma lista (array) de dicionários.
# Cada via(aresta) possui quatro parâmetros e seus valores, além das duas cidades que ela conecta
# Parâmetros e suas medidas: distancia(KM), tempo(min), Pedágio(R$), Acidentes(numero de acidentes por ano)
# Uma via conecta apenas duas cidades, e duas cidades são conectadas por uma única via
edges = [
    {"distancy": 15, "time": 15, "toll_cost": 6.00, "accidents": 60, "connections": ["Aspas", "Bambu"]},
    {"distancy": 60, "time": 60, "toll_cost": 9.00, "accidents": 30, "connections": ["Aspas", "Caju"]},
    {"distancy": 60, "time": 60, "toll_cost": 9.00, "accidents": 30, "connections": ["Aspas", "Estrela"]},
    {"distancy": 15, "time": 45, "toll_cost": 3.00, "accidents": 60, "connections": ["Aspas", "Florida"]},

    {"distancy": 90, "time": 90, "toll_cost": 3.00, "accidents": 60, "connections": ["Bambu", "Caju"]},
    {"distancy": 15, "time": 45, "toll_cost": 3.00, "accidents": 60, "connections": ["Bambu", "Florida"]},
    {"distancy": 90, "time": 90, "toll_cost": 3.00, "accidents": 60, "connections": ["Bambu", "Galia"]},
    {"distancy": 90, "time": 90, "toll_cost": 3.00, "accidents": 60, "connections": ["Bambu", "Jaci"]},
    {"distancy": 60, "time": 45, "toll_cost": 3.00, "accidents": 90, "connections": ["Bambu", "Kiel"]},

    {"distancy": 15, "time": 45, "toll_cost": 3.00, "accidents": 60, "connections": ["Caju", "Doce"]},
    {"distancy": 15, "time": 45, "toll_cost": 3.00, "accidents": 60, "connections": ["Caju", "Estrela"]},
    {"distancy": 15, "time": 45, "toll_cost": 3.00, "accidents": 60, "connections": ["Caju", "Florida"]},
    {"distancy": 15, "time": 45, "toll_cost": 3.00, "accidents": 60, "connections": ["Caju", "Galia"]},
    {"distancy": 15, "time": 45, "toll_cost": 3.00, "accidents": 60, "connections": ["Caju", "Hebra"]},
    {"distancy": 60, "time": 60, "toll_cost": 9.00, "accidents": 30, "connections": ["Caju", "Iaras"]},
    {"distancy": 15, "time": 45, "toll_cost": 3.00, "accidents": 60, "connections": ["Caju", "Jaci"]},
    {"distancy": 60, "time": 60, "toll_cost": 9.00, "accidents": 30, "connections": ["Caju", "Kiel"]},

    {"distancy": 15, "time": 45, "toll_cost": 3.00, "accidents": 60, "connections": ["Doce", "Estrela"]},
    {"distancy": 90, "time": 90, "toll_cost": 3.00, "accidents": 60, "connections": ["Doce", "Florida"]},
    {"distancy": 60, "time": 60, "toll_cost": 9.00, "accidents": 30, "connections": ["Doce", "Galia"]},
    {"distancy": 60, "time": 45, "toll_cost": 6.00, "accidents": 90, "connections": ["Doce", "Hebra"]},
    {"distancy": 60, "time": 45, "toll_cost": 6.00, "accidents": 90, "connections": ["Doce", "Iaras"]},
    {"distancy": 15, "time": 45, "toll_cost": 3.00, "accidents": 60, "connections": ["Doce", "Jaci"]},

    {"distancy": 15, "time": 45, "toll_cost": 3.00, "accidents": 60, "connections": ["Estrela", "Florida"]},
    {"distancy": 15, "time": 45, "toll_cost": 3.00, "accidents": 60, "connections": ["Estrela", "Hebra"]},
    {"distancy": 90, "time": 90, "toll_cost": 3.00, "accidents": 60, "connections": ["Estrela", "Iaras"]},

    {"distancy": 60, "time": 60, "toll_cost": 9.00, "accidents": 30, "connections": ["Florida", "Galia"]},
    {"distancy": 15, "time": 45, "toll_cost": 3.00, "accidents": 60, "connections": ["Florida", "Hebra"]},
    {"distancy": 60, "time": 60, "toll_cost": 9.00, "accidents": 30, "connections": ["Florida", "Kiel"]},

    {"distancy": 90, "time": 90, "toll_cost": 3.00, "accidents": 60, "connections": ["Galia", "Hebra"]},
    {"distancy": 60, "time": 60, "toll_cost": 9.00, "accidents": 30, "connections": ["Galia", "Iaras"]},
    {"distancy": 15, "time": 45, "toll_cost": 3.00, "accidents": 60, "connections": ["Galia", "Jaci"]},
    {"distancy": 15, "time": 45, "toll_cost": 3.00, "accidents": 60, "connections": ["Galia", "Kiel"]},

    {"distancy": 90, "time": 90, "toll_cost": 3.00, "accidents": 60, "connections": ["Hebra", "Kiel"]},

    {"distancy": 15, "time": 45, "toll_cost": 3.00, "accidents": 60, "connections": ["Iaras", "Jaci"]},
    {"distancy": 90, "time": 75, "toll_cost": 6.00,"accidents": 90, "connections": ["Iaras", "Kiel"]},
]

# Encontra a aresta que conecta dois nós, caso ela exista
def find_edge_between_nodes(start, end):
    for i in range(len(edges)):
        if ((edges[i]["connections"][0] == start and edges[i]["connections"][1] == end) or (edges[i]["connections"][0] == end and edges[i]["connections"][1] == start)):
            return edges[i]
    return

# Procura todos os caminhos possíveis entre duas cidades ("start" e "end") recursivamente
# e armazena todos esses caminhos em um vetor "all_paths"
def get_path (start, end, path, all_paths):
    path = path + [start]  # Adiciona novas cidades ao caminho
    if start == end:  # Entra nessa condição sempre que o caminho chegar a cidade destino
        all_paths.append(path)
        return
    for i in range(len(nodes[start])):  # Passa por todos as conexões da cidade "start"
        if nodes[start][i] not in path:  # Impede o caminho de repetir a mesma cidade
            next_node = nodes[start][i]  # Pega a próxima cidade do caminho
            get_path(next_node, end, path, all_paths)  # Utiliza a função recursivamente, até que a próxima cidade seja a cidade de destino

# Normaliza os valores de todos os parâmetros na aresta,
# Todos os valores dos parâmetros assumirão um valor de 0 a 1
# A normalização é feita para obter maior
def normalize_values ():
    n = len(edges)

    # Declarando os valores máximos e mínimos de todos os parâmetros das vias
    max_distancy = 90
    max_time = 90
    max_toll_cost = 9.00
    max_accidents = 90
    min_distancy = 15
    min_time = 15
    min_toll_cost = 3.00
    min_accidents = 30

    for i in range(n):  # Loop que passa por todas as vias e normaliza os parâmetros com a seguinte fórmula x = (x - x_min) / (x_max - x_min)
        edges[i]["distancy"] = (edges[i]["distancy"] - min_distancy) / (max_distancy - min_distancy)
        edges[i]["time"] = (edges[i]["time"] - min_time) / (max_time - min_time)
        edges[i]["toll_cost"] = (edges[i]["toll_cost"] - min_toll_cost) / (max_toll_cost - min_toll_cost)
        edges[i]["accidents"] = (edges[i]["accidents"] - min_accidents) / (max_accidents - min_accidents)

# Atribui peso para os parâmetros de prioridade escolidos pelo usuário
# # Quando menor o valor dos parâmetros, melhor o caminho, por isso o valor dos parâmetros de prioridade são divididos (reduzidos)
def set_parameter_weight(parameter1 ,parameter2):
    for i in range(len(edges)):
        edges[i][parameter1] /= 4
        edges[i][parameter2] /= 4

# Percorre o vetor com todos os caminhos encontrados
# Encontra o melhor caminho com base numa pontuação que considera os valores dos parametros no caminho e seu peso
# Quando menor o valor dos parâmetros, menor a pontuação, logo melhor o caminho
def get_best_path (all_paths): #Incompleto

    # Normalizando os valores
    normalize_values()

    # Atribuindo pesos aos parâmetros
    set_parameter_weight(parameters[parameter1], parameters[parameter2])

    best_path = []  # Vetor que armazena o melhor caminho
    best_score = -1  # Variável que armazena a menor pontuação
    for i in range(len(all_paths)):
        score = 0  # (Re)Inicializa a pontuação a cada caminho percorrido
        for j in range(len(all_paths[i])-1):
            edge = find_edge_between_nodes(all_paths[i][j], all_paths[i][j+1])
            edge_distancy = edge["distancy"]
            edge_time = edge["time"]
            edge_toll_cost = edge["toll_cost"]
            edge_accidents = edge["accidents"]
            score += edge_distancy + edge_time + edge_toll_cost + edge_accidents  # Adiciona a pontuação da via à pontuação do caminho
        if score < best_score or best_score == -1:  # Verifica se a pontuação do caminho é o menor (ou o primeiro) encontrado
            best_score = score  # Atualiza o valor da menor pontuação
            best_path = all_paths[i]  # Atualiza o melhor caminho
    return best_path

if __name__ == '__main__':

    #########################################################
    ###  Variaveis
    #########################################################
    parameters = {
        "1": "distancy",
        "2": "time",
        "3": "toll_cost",
        "4": "accidents"
    }
    all_paths = []
    path = []
    start = ""
    start_id = -1
    end = ""
    end_id = -1
    parameter1 = -1
    parameter2 = -1

    #########################################################
    #  Interface (pelo terminal)
    #########################################################

    for i in range(len(nodes["All_Cities"])):
        print(f'{i+1} - {nodes["All_Cities"][i]}')
    start_id = int(input("Selecione a cidade de partida: ")) - 1
    start = nodes["All_Cities"][start_id]

    end_id = start_id
    while end_id == start_id:
        for i in range(len(nodes["All_Cities"])):
            print(f'{i+1} - {nodes["All_Cities"][i]}')
        end_id = int(input("Selecione a cidade de destino: ")) - 1
        end = nodes["All_Cities"][end_id]
        if end_id == start_id:
            print("Sua cidade destino é a mesma que sua cidade de partida! Escolha outro destino!")

    while parameter1 not in ('1', '2', '3', '4'):
        print("Escolha um prioridade para sua rota:")
        print("1 - Quero percorrer a menor distância possível")
        print("2 - Quero percorrer a rota no menor tempo possível")
        print("3 - Quero ter o menor gasto com pedágios")
        print("4 - Busco uma rota com segurança e baixo indice de acidentes")
        parameter1 = input("Digite o número da opção que te melhor atende: ")
        if parameter1 not in ('1', '2', '3', '4'):
            print("Opção Inválida! Digite novamente!")
        print("")

    if parameter1 == '1':
        while parameter2 not in ('2', '3', '4'):
            print("Escolha uma segunda prioridade para sua rota:")
            print("2 - Quero percorrer a rota no menor tempo possível")
            print("3 - Quero ter o menor gasto com pedágios")
            print("4 - Busco uma rota com segurança e baixo indice de acidentes")
            parameter2 = input("Digite o número da opção que te melhor atende: ")
            if parameter2 not in ('2', '3', '4'):
                print("Opção Inválida! Digite novamente!")
            print("")
    elif parameter1 == '2':
        while parameter2 not in ('1', '3', '4'):
            print("Escolha uma segunda prioridade para sua rota:")
            print("1 - Quero percorrer a menor distância possível")
            print("3 - Quero ter o menor gasto com pedágios")
            print("4 - Busco uma rota com segurança e baixo indice de acidentes")
            parameter2 = input("Digite o número da opção que te melhor atende: ")
            if parameter2 not in ('1', '3', '4'):
                print("Opção Inválida! Digite novamente!")
            print("")
    elif parameter1 == '3':
        while parameter2 not in ('1', '2', '4'):
            print("Escolha uma segunda prioridade para sua rota:")
            print("1 - Quero percorrer a menor distância possível")
            print("2 - Quero percorrer a rota no menor tempo possível")
            print("4 - Busco uma rota com segurança e baixo indice de acidentes")
            parameter2 = input("Digite o número da opção que te melhor atende: ")
            if parameter2 not in ('1', '2', '4'):
                print("Opção Inválida! Digite novamente!")
            print("")
    elif parameter1 == '4':
        while parameter2 not in ('1', '2', '3'):
            print("Escolha uma segunda prioridade para sua rota:")
            print("1 - Quero percorrer a menor distância possível")
            print("2 - Quero percorrer a rota no menor tempo possível")
            print("3 - Quero ter o menor gasto com pedágios")
            parameter2 = input("Digite o número da opção que te melhor atende: ")
            if parameter2 not in ('1', '2', '3'):
                print("Opção Inválida! Digite novamente!")
            print("")

    #########################################################
    #  Encontrando a melhor rota
    #########################################################

    get_path(start, end, path, all_paths)  # Encontra todos os caminhos possíveis e armazena em um vetor all_paths
    best_path = get_best_path(all_paths)  # Encontra o melhor caminho dentre todos possíveis do vetor all_paths
    print(best_path)  # Imprime o melhor caminho (cidades por onde ele passa)
